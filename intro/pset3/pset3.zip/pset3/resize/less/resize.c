// Implement a program called resize that resizes (i.e., enlarges) 24-bit uncompressed BMPs by a factor of n.

#include <stdio.h>
#include <stdlib.h>

#include "bmp.h"

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        fprintf(stderr, "Usage: resize n infile outfile\n");
        return 1;
    }

    // remember filenames and factor n
    char *infile = argv[2];
    char *outfile = argv[3];
    int n = atoi(argv[1]);

    // check for n in range 1 - 100 inclusive
    if (n < 1 || n > 100)
    {
        printf("factor 'n' must be in between 1 - 100 (inclusive).\n");
        return 2;
    }

    // open input file
    FILE *inptr = fopen(infile, "r");
    if (inptr == NULL)
    {
        fprintf(stderr, "Could not open %s.\n", infile);
        return 2;
    }

    // open output file
    FILE *outptr = fopen(outfile, "w");
    if (outptr == NULL)
    {
        fclose(inptr);
        fprintf(stderr, "Could not create %s.\n", outfile);
        return 3;
    }

    // read infile's BITMAPFILEHEADER
    BITMAPFILEHEADER bf_in;
    fread(&bf_in, sizeof(BITMAPFILEHEADER), 1, inptr);

    // read infile's BITMAPINFOHEADER
    BITMAPINFOHEADER bi_in;
    fread(&bi_in, sizeof(BITMAPINFOHEADER), 1, inptr);

    // ensure infile is (likely) a 24-bit uncompressed BMP 4.0
    if (bf_in.bfType != 0x4d42 || bf_in.bfOffBits != 54 || bi_in.biSize != 40 ||
        bi_in.biBitCount != 24 || bi_in.biCompression != 0)
    {
        fclose(outptr);
        fclose(inptr);
        fprintf(stderr, "Unsupported file format.\n");
        return 4;
    }

    // determine padding for scanlines of infile
    int padding_in = (4 - (bi_in.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;

    // Setting outfile Headers and Editing them according to n
    BITMAPFILEHEADER bf_out = bf_in;
    BITMAPINFOHEADER bi_out = bi_in;
    bi_out.biHeight *= n;
    bi_out.biWidth *= n;
    int padding_out = (4 - (bi_out.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;
    bi_out.biSizeImage = ((sizeof(RGBTRIPLE) * bi_out.biWidth) + padding_out) * abs(bi_out.biHeight);
    bf_out.bfSize = bi_out.biSizeImage + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);


    // write outfile's BITMAPFILEHEADER
    fwrite(&bf_out, sizeof(BITMAPFILEHEADER), 1, outptr);

    // write outfile's BITMAPINFOHEADER
    fwrite(&bi_out, sizeof(BITMAPINFOHEADER), 1, outptr);

    const int arr_size = sizeof(RGBTRIPLE) * bi_out.biWidth;    // size of triple's array
    RGBTRIPLE *triples_arr = malloc(arr_size);
    if(triples_arr == NULL)
    {
        printf("Out Of Memory\n");
        return 3;
    }
    for (int i = 0, InHeight = abs(bi_in.biHeight); i < InHeight; i++)   // for each row
    {
        //temporary storage
        RGBTRIPLE triple;
        int pixel = 0;  // for each pixel in outfile
        for (int j = 0; j < bi_in.biWidth; j++)  // for each pixel in a row
        {
            fread(&triple, sizeof(RGBTRIPLE), 1, inptr);    // read one time
            for (int k = 0; k < n; k++) // write to array n times
            {
                triples_arr[pixel] = triple;
                pixel++;
            }
        }
        for (int k = 0; k < n; k++)          // write that array n times to outfile
        {
            fwrite(triples_arr, arr_size, 1, outptr);
            for (int p = 0; p < padding_out; p++)        // include padding in outfile
                fputc(0x00, outptr);
        }

            fseek(inptr, padding_in, SEEK_CUR);
    }

    // free triples's array memory space
    free(triples_arr);

    // close infile
    fclose(inptr);

    // close outfile
    fclose(outptr);

    // success
    return 0;
}
