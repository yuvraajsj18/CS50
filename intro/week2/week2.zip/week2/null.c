#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main()
{
    char arr0[60] = {'a', 'b', 'c', 'd', 'e'};
    char arr1[] = {'a', 'b', 'c', 'd', 'e', '\0'};
    char str[5] = "vwxyz";
    printf("%s\n%s\n", arr0, str);
    printf("%s\n", arr1);

    for(int i = 0 ; arr0[i] != '\0'; i++)
        printf("%i ", arr0[i]);

    return 0;
}