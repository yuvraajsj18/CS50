/*
    Program to implement caesar cypher --
    user input a key as an command line arg
    and a plain text in the program
    the program processes and print a scrambled string
    using the key.
*/

#include <cs50.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, string argv[])
{
    // checking whether key is passed or not
    if(argc != 2)
    {
         printf("Usage: ./caesar key\n");
         return 1;
    }
    // validating key -- every character is digit or not
    for(int i = 0; argv[1][i] != '\0'; i++)
    {
        if(!(isdigit(argv[1][i])))
        {
            printf("Usage: ./caesar key\n");
            return 1;
        }
    }
    int key = atoi(argv[1]);    // converting key from STRING --> INT
    string text = get_string("plaintext: ");     // getting plaintext

    for(int i = 0; text[i] != '\0'; i++)
    {
        int shift = text[i] + key;        //calculating the amount of shift
        if(isupper(text[i]))
        {
               while(shift > 90)
               {
                   shift = 64 + (shift % 90);         // if shift crosses 'Z' wrap it up
               }
                text[i] = shift;
        }
        else if(islower(text[i]))
        {
               while(shift > 122)
               {
                   shift = 96 + (shift % 122);         // if shift crosses 'z' wrap it up
               }
               text[i] = shift;
        }
    }

    printf("ciphertext: %s\n", text);
    return 0;
}


// I Love Coding .......