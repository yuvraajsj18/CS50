#include <stdio.h>

int main()
{
    printf("I Love Compilers\n");
    return 0;
}