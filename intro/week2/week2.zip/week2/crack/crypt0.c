#include <stdio.h>
#include <cs50.h>
#include <crypt.h>

int main()
{
    string key = get_string("Key: ");
    string salt = get_string("Salt: ");
    string hash = crypt(key, salt);
    printf("hash = %s\n", hash);
    return 0;
}
