#include <stdio.h>
#include <string.h>
#include <cs50.h>

int main()
{
    char big[] = "AAA";
    char small[] = "aaa";
    string key = get_string("Key: ");
    unsigned int i = 0;
    do
    {
        big[1] = 'A';
        small[1] = 'a';
        do
        {
             big[2] = 'A';
            small[2] = 'a';
            do
            {
                i++;
                for(int j = 0; j < 3; j++)
                    printf("%c", big[j]);
                printf(" ");
                for(int j = 0; j < 3; j++)
                    printf("%c",small[j]);
                printf("\n");
                if(strcmp(key, big) == 0 || strcmp(key, small) == 0)
                {
                    printf("Found at %i\n", i);
                    return 0;
                }
                big[2]++;
                small[2]++;
            }
            while((big[2] <= 'Z') || small[2] <= 'z');
            big[1]++;
            small[1]++;
        }
        while ((big[1] <= 'Z') || small[1] <= 'z');

        big[0]++;
        small[0]++;
    }
    while((big[0] <= 'Z') || small[0] <= 'z');

    return 0;
}
