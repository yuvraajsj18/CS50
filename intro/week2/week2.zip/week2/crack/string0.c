#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main()
{
    char arr[] = "Abcde";
    string str = "VWXYZ";
    char *ptr = "QWERTY";

    printf("arr = %s\n", arr);
    printf("str = %s\n", str);
    printf("ptr = %s\n", ptr);

    printf("arr[0] = %c\n", arr[0]);
    // printf("str[0] = %c\n", str[0]);
    printf("ptr[0] = %c\n", ptr[0]);

    arr[0] = 'V';
    // strcpy(str,"Aknkj");
    strcpy(ptr,"Coij");                                        //   ptr[0] = 'C';

    printf("arr[0] = %c\n", arr[0]);
    // printf("str[0] = %c\n", str[0]);
    printf("ptr[0] = %c\n", ptr[0]);

    return 0;
}