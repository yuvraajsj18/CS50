#include <stdio.h>
#include <string.h>
#include <cs50.h>

int brut_force(string key);

int main(void)
{

    string key = get_string("Key: ");
    int length = strlen(key);       // length of key
    //set base values -->
    char big[length], small[length];
    for(int k = 0; k < length; k++)
    {
        big[k] = 'A';
        small[k] = 'a';
    }
    int pos = brut_force(key, big, small);
    printf("Found at %i\n",pos);

    return 0;
}

int brut_force(string key, string big, string small)
{
    unsigned int i = 0;

    // Base case -------------->
    if ( (strcmp(key, big) == 0) || (strcmp(key, small) == 0) )
    {
        i++;
        return i;
    }

    // Recursive Case ---------->
    

    return 0;

}