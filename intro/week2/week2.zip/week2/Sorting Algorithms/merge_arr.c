#include <stdio.h>
#include <cs50.h>

void merge_arr(int arr[], int arr1[], int arr2[]);

const int size = 2;
const int size_s = size / 2;
int main(void)
{
    printf("Enter Two Sorted Array:\n");
    int arr1[size_s], arr2[size_s];
    printf("Array 1:\n");
    for(int i = 0; i < size_s; i++)
        arr1[i] = get_int("%i) ", i);
    printf("Array 2:\n");
    for(int i = 0; i < size_s; i++)
        arr2[i] = get_int("%i) ", i);

    int arr[size];
    merge_arr(arr, arr1, arr2);
    for(int i = 0; i < size; i++)
        printf("%i ", arr[i]);
    printf("\n");
    return 0;
}

void merge_arr(int arr[], int arr1[], int arr2[])
{
    int i, r, l;
    i = r = l = 0;
    while(l < size_s && r < size_s)
    {
        if(arr1[l] < arr2[r])
        {
            arr[i] = arr1[l];
            i++;
            l++;
        }
        else if(arr2[r] < arr1[l])
        {
            arr[i] = arr2[r];
            i++;
            r++;
        }
    }
    while(r < size_s)
    {
        arr[i] = arr2[r];
        i++;
        r++;
    }
     while(l < size_s)
    {
        arr[i] = arr1[l];
        i++;
        l++;
    }
}