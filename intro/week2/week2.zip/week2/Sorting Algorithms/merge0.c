#include <stdio.h>
#include <cs50.h>

void merge_arr(int arr[], int arr1[], int arr2[], int l_size, int r_size);
void merge_sort(int arr[], int n);

const int size = 6;

int main(void)
{
    int arr[size];

    // Input Elements Of Unsorted array --
    printf("Enter Elements:\n");
    for (int i = 0; i < size; i++)
        arr[i] = get_int("%i) ", i);

    merge_sort(arr, size);  // Calling Sorting Function

    // printing sorted array --
    printf("New Array: ");
    for (int i = 0; i < size; i++)
        printf("%i ", arr[i]);
    printf("\n");
    return 0;
}

void merge_sort(int arr[], int n)
{
    if (n > 1)
    {
        int half = n / 2;
        int l_size = half;
        int r_size = n - half;
        int l_arr[l_size], r_arr[r_size];
        for(int i = 0; i < l_size; i++)
            l_arr[i] = arr[i];
        for(int i = 0, j = half; i < r_size; i++, j++)
            r_arr[i] = arr[j];
        // Sorting the left half --
        merge_sort(l_arr, l_size);

        // Sorting the right half --
        merge_sort(r_arr, r_size);

        // merge the two halves --
        merge_arr(arr, l_arr, r_arr, l_size, r_size);
    }
    return;
}

void merge_arr(int arr[], int arr1[], int arr2[], int l_size, int r_size)
{
    int i, r, l;
    i = r = l = 0;
    while(l < l_size && r < r_size)
    {
        if(arr1[l] < arr2[r])
        {
            arr[i] = arr1[l];
            i++;
            l++;
        }
        else if(arr2[r] < arr1[l])
        {
            arr[i] = arr2[r];
            i++;
            r++;
        }
    }
    while(r < r_size)
    {
        arr[i] = arr2[r];
        i++;
        r++;
    }
     while(l < l_size)
    {
        arr[i] = arr1[l];
        i++;
        l++;
    }
}