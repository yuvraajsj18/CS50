#include <stdio.h>
#include <cs50.h>

void ins_sort(int arr[]);

const int size = 5;

int main(void)
{
    int ins_arr[size];
    printf("Enter elements:\n");
    for(int i = 0; i < size; i++)
        ins_arr[i] = get_int("%i) ", i + 1);
    ins_sort(ins_arr);
    printf("New array: ");
    for(int i = 0; i < size; i++)
        printf("%i ",ins_arr[i]);
    printf("\n");
    return 0;
}

void ins_sort(int arr[])
{
    for(int n = 1; n < size; n++)
    {
        int i = n - 1;
        int to_sort = arr[n];
        while (i >= 0 && to_sort < arr[i])
        {
                arr[i + 1] = arr[i];
                i--;
        }
            arr[i + 1] = to_sort;
    }
}