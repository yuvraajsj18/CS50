#include <stdio.h>
#include <cs50.h>

void ins_sort(int arr[]);

const int size = 10;

int main(void)
{
    int ins_arr[size];
    printf("Enter elements:\n");
    for(int i = 0; i < size; i++)
        ins_arr[i] = get_int("%i) ", i + 1);
    ins_sort(ins_arr);
    printf("New array: ");
    for(int i = 0; i < size; i++)
        printf("%i ",ins_arr[i]);
    printf("\n");
    return 0;
}

void ins_sort(int arr[])
{
    for(int n = 0; n < size; n++)
    {
        int r = n;
        int temp = arr[r];
        for (int i = n - 1; i >= 0; i--)
        {
            if (arr[n] < arr[i])
                r = i;
        }
        if(r != n)
        {
            for(int j = n - 1; j >= r; j--)
            {
                arr[j + 1] = arr[j];
            }
            arr[r] = temp;
        }
    }
}