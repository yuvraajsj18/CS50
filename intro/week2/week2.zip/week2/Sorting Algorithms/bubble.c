#include <stdio.h>
#include <cs50.h>

void bubble_sort(int *array);

const int size = 10;

int main(void)
{
    int bub_array[size];
    printf("Enter element - \n");
    for(int i = 0; i < size; i++)
        bub_array[i] = get_int("%i) ", i + 1);
    bubble_sort(&bub_array[0]);
    printf("New Array: ");
    for(int i = 0; i < size; i++)
        printf("%i ",bub_array[i]);
    printf("\n");

    return 0;
}

void bubble_sort(int *array)
{
    int swaps;
    int steps = 0;
    do
    {
        swaps = 0;
        for(int i = 0; i < size - 1; i++)
        {
            if(array[i] > array[i + 1])
            {
                int temp = array[i];
                array[i] = array[i + 1];
                array[i + 1] = temp;
                swaps++;
            }
            steps++;
        }
    }while(swaps > 0);

            printf("%i\n", steps);
}