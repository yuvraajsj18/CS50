#include <stdio.h>
#include <cs50.h>

void sel_sort(int array[]);

const int size = 10;

int main(void)
{
    int sel_array[size];
    printf("Enter elements: \n");
    for (int i = 0; i < size; i++)
        sel_array[i] = get_int("%i) ", i + 1);
    sel_sort(sel_array);
    printf("New array: \n");
    for (int i = 0; i < size; i++)
        printf("%i ",sel_array[i]);
    printf("\n");

    return 0;
}

void sel_sort(int array[])
{
    int steps = 0;
       for(int i = 0; i < size - 1; i++)
       {
           int min = i;
           for(int j = i + 1; j < size; j++)
            {
               if( array[j] < array[min] )
                min = j;
                steps++;
            }
           if(min != i)
            {
                int temp = array[min];
                array[min] = array[i];
                array[i] = temp;
            }
       }
        printf("%i\n", steps);
}